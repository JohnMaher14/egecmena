import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inner-page-loader',
  templateUrl: './inner-page-loader.component.html',
  styleUrls: ['./inner-page-loader.component.scss']
})
export class InnerPageLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
