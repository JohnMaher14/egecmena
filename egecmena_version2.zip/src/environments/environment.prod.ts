export const environment = {
  production: true,
  apiKey: `https://digitalbondmena.com/egecNewMobileApp/api/`,
  imageUrl: `https://digitalbondmena.com/egec_new_new/`,
  title: `EGEC | `
};
