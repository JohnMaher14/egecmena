import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-loader',
  templateUrl: './home-loader.component.html',
  styleUrls: ['./home-loader.component.scss']
})
export class HomeLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
